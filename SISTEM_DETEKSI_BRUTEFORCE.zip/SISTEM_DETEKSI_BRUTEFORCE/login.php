<?php
session_start();
require "app/helpers/Security.php";
?>

<!doctype html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Login Sistem</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="container">

<div class="row justify-content-center align-items-center vh-100">

<div class="col-lg-5">

<div class="card login-card">

<div class="card-body p-5">

<div class="text-center">

<div class="logo">

🔐

</div>

<h1 class="fw-bold text-primary">

Login System

</h1>

<p class="subtitle">

Deteksi Serangan Brute Force Menggunakan Pendekatan Threshold

</p>

</div>

<?php

$alertMessage = null;

if(isset($_SESSION['error'])){

    $alertType = $_SESSION['alert_type'] ?? "danger";
    $alertClass = $alertType === "bruteforce" ? "text-bg-warning" : "text-bg-danger";
    $alertTitle = $alertType === "bruteforce" ? "Brute Force Terdeteksi" : null;
    $alertMessage = htmlspecialchars($_SESSION['error']);

    unset($_SESSION['error']);
    unset($_SESSION['alert_type']);
}

?>

<?php if($alertMessage): ?>
<div id="bfAlert" style="position:fixed; top:1rem; right:1rem; z-index:1200; width: min(360px, calc(100vw - 2rem));">
    <div style="background:#ffc107; color:#000; border:1px solid #e0a800; border-radius:.75rem; box-shadow:0 0.5rem 1rem rgba(0,0,0,.15); padding:1rem; display:flex; gap:.75rem; align-items:flex-start;">
        <div style="flex:1;">
            <?php if($alertTitle): ?>
                <strong><?= $alertTitle ?></strong><br>
            <?php endif; ?>
            <?= $alertMessage ?>
        </div>
        <button type="button" onclick="document.getElementById('bfAlert').style.display='none'" style="background:transparent; border:none; color:#000; font-size:1.25rem; line-height:1; cursor:pointer; padding:0;">&times;</button>
    </div>
</div>
<?php endif; ?>

<form action="app/controllers/LoginController.php" method="POST">

<?= csrf_field(); ?>

<div class="mb-3">

<label class="fw-bold">

Username

</label>

<div class="input-group">

<span class="input-group-text">

<i class="bi bi-person"></i>

</span>

<input

type="text"

name="username"

class="form-control"

placeholder="Masukkan Username"

required>

</div>

</div>

<div class="mb-4">

<label class="fw-bold">

Password

</label>

<div class="input-group">

<span class="input-group-text">

<i class="bi bi-lock"></i>

</span>

<input

type="password"

name="password"

class="form-control"

placeholder="Masukkan Password"

required>

</div>

</div>

<button

class="btn btn-login w-100"

name="login">

LOGIN

</button>

<div class="d-flex justify-content-between mt-3">

    <a href="forgot_password.php"
       class="text-decoration-none">
        <i class="bi bi-key"></i>
        Lupa Password?
    </a>

    <a href="register.php"
       class="text-decoration-none">
        <i class="bi bi-person-plus"></i>
        Buat Akun
    </a>

</div>

</form>

<div class="text-center mt-4 footer">

©2026 Sistem Deteksi Brute Force

</div>

</div>

</div>

</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php if($alertMessage): ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var bfToast = document.getElementById('bfToast');
        if (bfToast) {
            var toast = new bootstrap.Toast(bfToast, {
                autohide: false
            });
            toast.show();
        }
    });
</script>
<?php endif; ?>

</body>

</html>
