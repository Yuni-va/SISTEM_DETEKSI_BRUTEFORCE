<?php

require_once "config/database.php";
require_once "app/models/User.php";

$model = new User($conn);
$editUser = null;

if(isset($_GET['search']) && $_GET['search']!=""){
    $users = $model->search($_GET['search']);
}else{
    $users = $model->getAll();
}

if(isset($_GET['edit']) && $_GET['edit']!=""){
    $editUser = $model->find((int) $_GET['edit']);
}

?>

<?php if($editUser){ ?>

<div class="card shadow mb-4">

    <div class="card-header bg-warning d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-pencil-square"></i>
            Edit User
        </h5>

        <a href="users.php" class="btn btn-light btn-sm">
            <i class="bi bi-x-circle"></i>
            Batal
        </a>
    </div>

    <div class="card-body">

        <form action="app/controllers/UserController.php" method="POST">

            <?= csrf_field(); ?>

            <input type="hidden" name="id" value="<?= htmlspecialchars($editUser['id']) ?>">

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input
                        type="text"
                        name="fullname"
                        class="form-control"
                        value="<?= htmlspecialchars($editUser['fullName']) ?>"
                        required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Username</label>
                    <input
                        type="text"
                        name="username"
                        class="form-control"
                        value="<?= htmlspecialchars($editUser['username']) ?>"
                        required>
                </div>

            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input
                        type="email"
                        name="email"
                        class="form-control"
                        value="<?= htmlspecialchars($editUser['email']) ?>"
                        required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Password Baru</label>
                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        placeholder="Kosongkan jika tidak diubah">
                </div>

            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-select">
                        <option
                            value="Administrator"
                            <?= $editUser['role']=="Administrator" ? "selected" : "" ?>>
                            Administrator
                        </option>
                        <option
                            value="User"
                            <?= $editUser['role']=="User" ? "selected" : "" ?>>
                            User
                        </option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option
                            value="active"
                            <?= $editUser['status']=="active" ? "selected" : "" ?>>
                            Active
                        </option>
                        <option
                            value="inactive"
                            <?= $editUser['status']=="inactive" ? "selected" : "" ?>>
                            Inactive
                        </option>
                    </select>
                </div>

            </div>

            <button type="submit" name="update" class="btn btn-warning">
                <i class="bi bi-save"></i>
                Update
            </button>

            <a href="users.php" class="btn btn-secondary">
                Batal
            </a>

        </form>

    </div>

</div>

<?php }elseif(isset($_GET['edit'])){ ?>

<div class="alert alert-danger">
    Data user tidak ditemukan.
</div>

<?php } ?>

<?php if(isset($_GET['create'])){ ?>

<div class="card shadow mb-4">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-person-plus-fill"></i>
            Tambah User
        </h5>

        <a href="users.php" class="btn btn-light btn-sm">
            <i class="bi bi-x-circle"></i>
            Batal
        </a>
    </div>

    <div class="card-body">

        <form action="app/controllers/UserController.php" method="POST">

            <?= csrf_field(); ?>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="fullname" class="form-control" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" required>
                </div>

            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

            </div>

            <div class="row">

                <div class="col-md-6 mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-select">
                        <option value="Administrator">Administrator</option>
                        <option value="User" selected>User</option>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active" selected>Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>

            </div>

            <button type="submit" name="add" class="btn btn-primary">
                <i class="bi bi-save"></i>
                Simpan
            </button>

            <a href="users.php" class="btn btn-secondary">
                Batal
            </a>

        </form>

    </div>

</div>

<?php } ?>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

        <h5 class="mb-0">
            <i class="bi bi-people-fill"></i>
            Data User
        </h5>

        <a
            href="users.php?create=1"
            class="btn btn-light btn-sm"
            data-bs-toggle="modal"
            data-bs-target="#modalTambah">

            <i class="bi bi-plus-circle"></i>
            Tambah User

        </a>

    </div>

    <div class="card-body">

        <?php if(isset($_SESSION['success'])){ ?>

        <div class="alert alert-success">

            <?= $_SESSION['success']; ?>

        </div>

        <?php unset($_SESSION['success']); } ?>


        <?php if(isset($_SESSION['error'])){ ?>

        <div class="alert alert-danger">

            <?= $_SESSION['error']; ?>

        </div>

        <?php unset($_SESSION['error']); } ?>


        <form method="GET" class="mb-3">

            <div class="input-group">

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Cari user..."
                    value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">

                <button class="btn btn-primary">

                    Cari

                </button>

            </div>

        </form>

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">

                <tr>

                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th width="170">Aksi</th>

                </tr>

                </thead>

                <tbody>

                <?php

                $no=1;

                while($row=mysqli_fetch_assoc($users)){

                $profilePhoto = $row['profile_photo'] ?? "";
                $profilePhotoPath = "assets/uploads/profile/".$profilePhoto;
                $hasProfilePhoto = $profilePhoto !== "" && file_exists($profilePhotoPath);
                $profileInitial = strtoupper(substr($row['fullName'] ?? $row['username'] ?? "U",0,1));

                ?>

                <tr>

                    <td><?= $no++ ?></td>

                    <td width="70">

                        <?php if($hasProfilePhoto){ ?>

                            <img
                                src="<?= htmlspecialchars($profilePhotoPath) ?>"
                                width="45"
                                height="45"
                                class="rounded-circle border"
                                style="object-fit:cover;">

                        <?php }else{ ?>

                            <span
                                class="rounded-circle border bg-primary text-white d-inline-flex align-items-center justify-content-center"
                                style="width:45px;height:45px;font-weight:700;">
                                <?= htmlspecialchars($profileInitial) ?>
                            </span>

                        <?php } ?>

                    </td>

                    <td><?= htmlspecialchars($row['fullName']) ?></td>

                    <td><?= htmlspecialchars($row['username']) ?></td>

                    <td><?= htmlspecialchars($row['email']) ?></td>

                    <td>
                        

<?php if (strtolower(trim($row['role'])) == 'admin') { ?>

    <span class="badge bg-danger">
        <i class="bi bi-shield-lock-fill"></i> Administrator

    </span>

<?php } else { ?>

    <span class="badge bg-primary">
        <i class="bi bi-person-fill"></i> user
        
    </span>

<?php } ?>

</td>

                    <td>

                        <?php

                        if($row['status']=="active"){

                            echo "<span class='badge bg-success'>Active</span>";

                        }else{

                            echo "<span class='badge bg-danger'>Inactive</span>";

                        }

                        ?>

                    </td>

                    <td>

                        <a
                            href="users.php?edit=<?= $row['id'] ?>"
                            class="btn btn-warning btn-sm">

                            Edit

                        </a>

                        <form
                            action="app/controllers/UserController.php"
                            method="POST"
                            class="d-inline"
                            onsubmit="return confirm('Hapus user ini?')">

                            <?= csrf_field(); ?>

                            <input
                                type="hidden"
                                name="id"
                                value="<?= htmlspecialchars($row['id']) ?>">

                            <button
                                type="submit"
                                name="delete"
                                class="btn btn-danger btn-sm">

                                Hapus

                            </button>

                        </form>

                    </td>

                </tr>

                <?php include "app/views/users/edit.php"; ?>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include "app/views/users/create.php"; ?>
