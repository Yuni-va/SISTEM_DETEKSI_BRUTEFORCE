<?php

require_once "config/database.php";
require_once "app/models/Dashboard.php";
require_once "app/models/Setting.php";

$dashboard = new Dashboard($conn);
$settingModel = new Setting($conn);

$totalUser      = $dashboard->totalUser();
$totalFailed    = $dashboard->totalFailedLogin();
$totalBlocked   = $dashboard->totalBlockedIP();
$totalSuccess   = $dashboard->totalSuccessLogin();
$totalDetection = $dashboard->totalDetection();
$chart          = $dashboard->chartLoginSeries();
$config         = $settingModel->securityConfig();
$suspiciousIp   = $dashboard->suspiciousIpToday();
$topAttackers   = $dashboard->topAttackers(5);
$fail24         = $dashboard->failedLast24Hours();
$recentEvents   = $dashboard->recentSecurityEvents(5);
$blockedIps     = $dashboard->latestBlockedIps(4);
$lastDetection  = $dashboard->lastDetectionTime();

$riskLevel = "Normal";
$riskClass = "success";
$engineState = "RUNNING";

if($totalBlocked > 0 || $totalDetection > 0){
    $riskLevel = "Alert";
    $riskClass = "warning";
}

if($totalFailed >= 10){
    $riskLevel = "High Risk";
    $riskClass = "danger";
}

$kpis = [
    [
        "label" => "Total Users",
        "value" => number_format((int)$totalUser),
        "meta" => "Pengguna",
        "icon" => "bi bi-people-fill",
        "tone" => "primary"
    ],
    [
        "label" => "Login Berhasil",
        "value" => number_format((int)$totalSuccess),
        "meta" => "Successful authentication",
        "icon" => "bi bi-check-circle-fill",
        "tone" => "success"
    ],
    [
        "label" => "Login Gagal",
        "value" => number_format((int)$totalFailed),
        "meta" => "Failed authentication",
        "icon" => "bi bi-x-circle-fill",
        "tone" => "danger"
    ],
    [
        "label" => "IP Diblokir",
        "value" => number_format((int)$totalBlocked),
        "meta" => "Active blocked IP",
        "icon" => "bi bi-lock-fill",
        "tone" => "warning"
    ],
    [
        "label" => "Ambang Peringatan",
        "value" => htmlspecialchars($config['threshold_limit'])." / ".htmlspecialchars($config['detection_window_minutes']),
        "meta" => "gagal / menit",
        "icon" => "bi bi-shield-lock-fill",
        "tone" => "purple"
    ],
    [
        "label" => "Deteksi Terkumulasi",
        "value" => number_format((int)$totalDetection),
        "meta" => "Detection count",
        "icon" => "bi bi-activity",
        "tone" => "cyan"
    ],
];

?>

<div class="soc-dashboard">

    <section class="soc-kpi-grid">
        <?php foreach($kpis as $kpi): ?>
            <article class="soc-kpi-card">
                <div class="soc-kpi-icon tone-<?= $kpi['tone'] ?>">
                    <i class="<?= $kpi['icon'] ?>"></i>
                </div>
                <div class="soc-kpi-content">
                    <span><?= $kpi['label'] ?></span>
                    <strong><?= $kpi['value'] ?></strong>
                    <small><?= $kpi['meta'] ?></small>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="soc-row soc-row-main">
        <article class="soc-card soc-chart-card">
            <div class="soc-card-header">
                <div>
                    <span class="soc-eyebrow">Grafik</span>
                    <h5>Login Attempts</h5>
                </div>
                <span class="soc-chip"><i class="bi bi-calendar3"></i> Harian</span>
            </div>
            <div class="soc-chart-shell soc-chart-large">
                <canvas id="loginChart"></canvas>
            </div>
        </article>

        <article class="soc-card soc-insight-card">
            <div class="soc-card-header">
                <div>
                    <span class="soc-eyebrow">Insight</span>
                    <h5>Analisis Singkat</h5>
                </div>
                <span class="risk-badge risk-<?= $riskClass ?>"><?= $riskLevel ?></span>
            </div>

            <p>
                Dashboard ini memantau percobaan login dan mengklasifikasikan pola gagal sebagai indikasi brute force ketika ambang batas tercapai.
            </p>
            <p>
                Threshold aktif saat ini adalah <?= htmlspecialchars($config['threshold_limit']) ?> login gagal dalam <?= htmlspecialchars($config['detection_window_minutes']) ?> menit. IP yang melewati batas otomatis diblokir selama <?= htmlspecialchars($config['block_minutes']) ?> menit.
            </p>

            <div class="insight-grid">
                <div class="insight-metric border-danger">
                    <span>Threshold Aktif</span>
                    <strong><?= htmlspecialchars($config['threshold_limit']) ?> gagal / <?= htmlspecialchars($config['detection_window_minutes']) ?> menit</strong>
                    <small>Block <?= htmlspecialchars($config['block_minutes']) ?> menit</small>
                </div>
                <div class="insight-metric border-primary">
                    <span>IP Paling Mencurigakan Hari Ini</span>
                    <strong><?= htmlspecialchars($suspiciousIp['ip_address']) ?></strong>
                    <small><?= htmlspecialchars($suspiciousIp['total_failed']) ?> login gagal</small>
                </div>
            </div>
        </article>

        <?php include __DIR__ . '/_recent_events.php'; ?>
    </section>

    <section class="soc-row soc-row-secondary">
        <?php include __DIR__ . '/_widgets_fail_distribution.php'; ?>

        <?php include __DIR__ . '/_widgets_top_attackers.php'; ?>

        <article class="soc-card blocked-ip-panel">
            <div class="soc-card-header">
                <div>
                    <span class="soc-eyebrow">Daftar IP Diblokir</span>
                    <h5>Blocked IP</h5>
                </div>
                <a class="soc-link" href="blocked_ips.php">Lihat Semua</a>
            </div>

            <div class="soc-table-wrap">
                <table class="table soc-table align-middle">
                    <thead>
                        <tr>
                            <th>IP Address</th>
                            <th>Diblokir Pada</th>
                            <th>Sampai</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($blockedIps) === 0): ?>
                            <tr>
                                <td colspan="4" class="empty-cell">Belum ada IP yang diblokir.</td>
                            </tr>
                        <?php endif; ?>

                        <?php while($blocked = mysqli_fetch_assoc($blockedIps)): ?>
                            <tr>
                                <td><?= htmlspecialchars($blocked['ip_address']) ?></td>
                                <td><?= date('d M Y H:i', strtotime($blocked['blocked_at'])) ?></td>
                                <td><?= $blocked['blocked_until'] ? date('d M Y H:i', strtotime($blocked['blocked_until'])) : '-' ?></td>
                                <td>
                                    <span class="table-status <?= $blocked['status'] === 'blocked' ? 'blocked' : 'released' ?>">
                                        <?= htmlspecialchars(strtoupper($blocked['status'])) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </article>
    </section>

    <section class="soc-row soc-row-bottom">
        <article class="soc-card config-card">
            <div class="config-icon tone-primary">
                <i class="bi bi-gear-fill"></i>
            </div>
            <div class="config-body">
                <span class="soc-eyebrow">Konfigurasi Sistem</span>
                <div class="config-grid">
                    <div>
                        <span>Threshold</span>
                        <strong><?= htmlspecialchars($config['threshold_limit']) ?> attempts</strong>
                    </div>
                    <div>
                        <span>Time Window</span>
                        <strong><?= htmlspecialchars($config['detection_window_minutes']) ?> menit</strong>
                    </div>
                    <div>
                        <span>Block Duration</span>
                        <strong><?= htmlspecialchars($config['block_minutes']) ?> menit</strong>
                    </div>
                    <div>
                        <span>Detection Method</span>
                        <strong>Threshold Based</strong>
                    </div>
                </div>
            </div>
        </article>

        <article class="soc-card engine-card">
            <div class="engine-emblem">
                <i class="bi bi-shield-check"></i>
            </div>
            <div class="engine-body">
                <span class="soc-eyebrow">Detection Engine</span>
                <div class="engine-grid">
                    <div>
                        <span>Status</span>
                        <strong class="engine-running"><?= $engineState ?></strong>
                    </div>
                    <div>
                        <span>Last Detection</span>
                        <strong><?= $lastDetection ? date('d M Y H:i:s', strtotime($lastDetection)) : '-' ?></strong>
                    </div>
                    <div>
                        <span>Total Detections</span>
                        <strong><?= number_format((int)$totalDetection) ?></strong>
                    </div>
                    <div>
                        <span>Accuracy</span>
                        <strong>100%</strong>
                    </div>
                </div>
            </div>
        </article>
    </section>

</div>

<script>
const chartLabels = [
<?php foreach($chart as $row){ echo "'".$row['tanggal']."',"; } ?>
];

const chartSuccessData = [
<?php foreach($chart as $row){ echo (int)$row['success_total'].","; } ?>
];

const chartFailedData = [
<?php foreach($chart as $row){ echo (int)$row['failed_total'].","; } ?>
];

const topAttackersLabels = [
<?php
mysqli_data_seek($topAttackers, 0);
while($r = mysqli_fetch_assoc($topAttackers)){
    echo "'". $r['ip_address'] ."',";
}
?>
];

const topAttackersData = [
<?php
mysqli_data_seek($topAttackers, 0);
while($r = mysqli_fetch_assoc($topAttackers)){
    echo (int)$r['total_failed'] .",";
}
?>
];

const fail24Labels = [<?php for($h=0;$h<24;$h++){ echo "'".sprintf('%02d:00',$h)."',"; } ?>];
const fail24Data = [<?php echo implode(',', $fail24); ?>];
</script>
