<?php

require_once "app/models/Setting.php";

$model = new Setting($conn);
$config = $model->securityConfig();
$menus = $model->getMenus();

$securitySettings = [
    [
        "label" => "Batas Login Gagal",
        "name" => "threshold_limit",
        "type" => "number",
        "suffix" => "percobaan",
        "value" => $config['threshold_limit'],
        "description" => "Jumlah maksimal login gagal sebelum IP diblokir."
    ],
    [
        "label" => "Rentang Deteksi",
        "name" => "detection_window_minutes",
        "type" => "number",
        "suffix" => "menit",
        "value" => $config['detection_window_minutes'],
        "description" => "Periode waktu untuk menghitung percobaan login gagal."
    ],
    [
        "label" => "Durasi Blokir",
        "name" => "block_minutes",
        "type" => "number",
        "suffix" => "menit",
        "value" => $config['block_minutes'],
        "description" => "Lama IP diblokir setelah melewati batas threshold."
    ],
    [
        "label" => "Retensi Log",
        "name" => "log_retention_days",
        "type" => "number",
        "suffix" => "hari",
        "value" => $config['log_retention_days'],
        "description" => "Log lama akan diarsipkan sebelum dibersihkan dari tabel utama."
    ],
    [
        "label" => "Auto Cleanup Log",
        "name" => "auto_cleanup_enabled",
        "type" => "checkbox",
        "suffix" => "",
        "value" => $config['auto_cleanup_enabled'],
        "description" => "Aktifkan arsip dan hapus log lama secara otomatis sesuai retensi."
    ],
    [
        "label" => "Token API",
        "name" => "api_token",
        "type" => "text",
        "suffix" => "",
        "value" => $config['api_token'],
        "description" => "Token untuk mengakses endpoint API detect dan report."
    ]
];

?>

<?php if(isset($_SESSION['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['success']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>

<?php unset($_SESSION['success']); } ?>

<div class="row mb-4">

    <div class="col-lg-8 mb-3">

        <div class="card shadow h-100">

            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="bi bi-gear-fill"></i>
                    Settings
                </h5>
            </div>

            <div class="card-body">

                <form method="POST" action="app/controllers/SettingsController.php">

                    <?= csrf_field(); ?>
                    <input type="hidden" name="auto_cleanup_enabled" value="0">

                    <div class="table-responsive">

                        <table class="table table-bordered table-hover align-middle">

                            <thead class="table-dark">
                                <tr>
                                    <th width="70">No</th>
                                    <th>Pengaturan</th>
                                    <th width="260">Nilai</th>
                                    <th>Keterangan</th>
                                    <th width="130">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>

                            <?php

                            $no=1;

                            foreach($securitySettings as $setting){

                            ?>

                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($setting['label']) ?></td>
                                    <td>
                                        <div class="input-group input-group-sm">
                                            <?php if($setting['type'] === 'checkbox') { ?>
                                                <div class="form-check">
                                                    <input
                                                        class="form-check-input"
                                                        type="checkbox"
                                                        name="<?= htmlspecialchars($setting['name']) ?>"
                                                        id="<?= htmlspecialchars($setting['name']) ?>"
                                                        value="1"
                                                        <?= $setting['value'] ? 'checked' : '' ?>>
                                                    <label class="form-check-label" for="<?= htmlspecialchars($setting['name']) ?>">
                                                        Aktif
                                                    </label>
                                                </div>
                                            <?php } else { ?>
                                                <input
                                                    type="<?= htmlspecialchars($setting['type']) ?>"
                                                    <?= $setting['type'] === "number" ? 'min="1"' : "" ?>
                                                    name="<?= htmlspecialchars($setting['name']) ?>"
                                                    class="form-control"
                                                    value="<?= htmlspecialchars($setting['value']) ?>">
                                            <?php } ?>

                                            <?php if($setting['suffix'] !== ""){ ?>
                                                <span class="input-group-text">
                                                    <?= htmlspecialchars($setting['suffix']) ?>
                                                </span>
                                            <?php } ?>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($setting['description']) ?></td>
                                    <td>
                                        <button
                                            class="btn btn-primary btn-sm w-100"
                                            name="save_security">
                                            <i class="bi bi-save"></i>
                                            Simpan
                                        </button>
                                    </td>
                                </tr>

                            <?php } ?>

                            </tbody>

                        </table>

                    </div>

                </form>

            </div>

        </div>

    </div>

    <div class="col-lg-4 mb-3">

        <div class="card shadow h-100">

            <div class="card-header bg-success text-white">
                <h5 class="mb-0">
                    <i class="bi bi-shield-check"></i>
                    Status Sistem
                </h5>
            </div>

            <div class="card-body">

                <div class="mb-4">
                    <h6>Deteksi Brute Force</h6>
                    <span class="badge bg-success">Aktif</span>
                </div>

                <div class="mb-4">
                    <h6>Metode Deteksi</h6>
                    <p class="mb-0">
                        Threshold berdasarkan jumlah login gagal dari IP yang sama.
                    </p>
                </div>

                <div>
                    <h6>Respons Sistem</h6>
                    <p class="mb-0">
                        IP otomatis masuk ke blocked list dan event dicatat pada threshold, detection, dan system logs.
                    </p>
                </div>

            </div>

        </div>

    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-list-check"></i>
            Pengaturan Menu
        </h5>
    </div>

    <div class="card-body">

        <form method="POST" action="app/controllers/SettingsController.php">

            <?= csrf_field(); ?>

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-dark">
                        <tr>
                            <th width="70">No</th>
                            <th>Menu</th>
                            <th>URL</th>
                            <th width="160">Status</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php

                    $no=1;

                    while($menu=mysqli_fetch_assoc($menus)){

                        $isSettings = $menu['menu_key']=="settings";

                    ?>

                        <tr>
                            <td><?= $no++ ?></td>

                            <td>
                                <i class="<?= htmlspecialchars($menu['icon']) ?>"></i>
                                <?= htmlspecialchars($menu['label']) ?>
                            </td>

                            <td><?= htmlspecialchars($menu['url']) ?></td>

                            <td>
                                <div class="form-check form-switch">
                                    <input
                                        class="form-check-input"
                                        type="checkbox"
                                        name="menus[]"
                                        value="<?= htmlspecialchars($menu['menu_key']) ?>"
                                        id="menu_<?= htmlspecialchars($menu['menu_key']) ?>"
                                        <?= $menu['is_active'] ? "checked" : "" ?>
                                        <?= $isSettings ? "disabled" : "" ?>>

                                    <?php if($isSettings){ ?>
                                        <input
                                            type="hidden"
                                            name="menus[]"
                                            value="settings">
                                    <?php } ?>

                                    <label
                                        class="form-check-label"
                                        for="menu_<?= htmlspecialchars($menu['menu_key']) ?>">
                                        <?= $menu['is_active'] ? "Aktif" : "Nonaktif" ?>
                                    </label>
                                </div>
                            </td>
                        </tr>

                    <?php } ?>

                    </tbody>

                </table>

            </div>

            <div class="d-flex justify-content-end">
                <button class="btn btn-primary" name="save_menus">
                    <i class="bi bi-save"></i>
                    Simpan Pengaturan Menu
                </button>
            </div>

        </form>

    </div>

</div>
