<?php

require_once "config/database.php";
require_once "app/models/DetectionLog.php";

$model = new DetectionLog($conn);

$search = trim($_GET['search'] ?? "");
$from = trim($_GET['from'] ?? "");
$to = trim($_GET['to'] ?? "");

$data = $model->filter($search,$from,$to);

$total = $model->total();
$today = $model->today();
$week  = $model->week();

?>

<div class="row mb-4">

    <div class="col-md-4">
        <div class="card bg-danger text-white shadow">
            <div class="card-body">
                <h6>Total Detection</h6>
                <h2><?= $total ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <h6>Hari Ini</h6>
                <h2><?= $today ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                <h6>Minggu Ini</h6>
                <h2><?= $week ?></h2>
            </div>
        </div>
    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

        <h5 class="mb-0">
            <i class="bi bi-shield-exclamation"></i>
            Detection Logs
        </h5>

        <a href="detection_logs.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-clockwise"></i>
            Refresh
        </a>

    </div>

    <div class="card-body">

        <form method="GET" class="row g-2 mb-3 align-items-end">

            <div class="col-md-4">
                <label class="form-label">Cari</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Username / IP / Tipe Deteksi..."
                    value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Dari Tanggal</label>
                <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Sampai Tanggal</label>
                <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
            </div>

            <div class="col-md-2">
                <button class="btn btn-primary w-100">
                    <i class="bi bi-search"></i>
                    Filter
                </button>
            </div>

        </form>

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">

                    <tr>
                        <th width="70">No</th>
                        <th>Username</th>
                        <th>IP Address</th>
                        <th>Tipe Deteksi</th>
                        <th>Deskripsi</th>
                        <th>Waktu Deteksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no=1;

                while($row=mysqli_fetch_assoc($data)){

                ?>

                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['ip_address']) ?></td>
                        <td>
                            <span class="badge bg-danger">
                                <?= htmlspecialchars($row['detection_type']) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($row['description']) ?></td>
                        <td><?= date('d-m-Y H:i:s',strtotime($row['detected_at'])) ?></td>
                    </tr>

                <?php } ?>

                <?php if(mysqli_num_rows($data)===0){ ?>

                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Data detection logs belum tersedia.
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>
