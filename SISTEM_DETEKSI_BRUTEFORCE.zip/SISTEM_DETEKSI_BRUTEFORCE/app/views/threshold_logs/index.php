<?php

require_once "config/database.php";
require_once "app/models/ThresholdLog.php";

$model = new ThresholdLog($conn);

$search = trim($_GET['search'] ?? "");
$from = trim($_GET['from'] ?? "");
$to = trim($_GET['to'] ?? "");

$data = $model->filter($search,$from,$to);

$total = $model->total();
$today = $model->today();
$week  = $model->week();

?>

<div class="row mb-4">

    <div class="col-md-4">
        <div class="card bg-danger text-white shadow">
            <div class="card-body">
                <h6>Total Threshold</h6>
                <h2><?= $total ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <h6>Hari Ini</h6>
                <h2><?= $today ?></h2>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                <h6>Minggu Ini</h6>
                <h2><?= $week ?></h2>
            </div>
        </div>
    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

        <h5 class="mb-0">
            <i class="bi bi-sliders"></i>
            Threshold Logs
        </h5>

        <a href="threshold_logs.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-clockwise"></i>
            Refresh
        </a>

    </div>

    <div class="card-body">

        <form method="GET" class="row g-2 mb-3 align-items-end">

            <div class="col-md-4">
                <label class="form-label">Cari</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="IP Address / Aksi..."
                    value="<?= htmlspecialchars($search) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Dari Tanggal</label>
                <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label">Sampai Tanggal</label>
                <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>">
            </div>

            <div class="col-md-2">
                <button class="btn btn-primary w-100">
                    <i class="bi bi-search"></i>
                    Filter
                </button>
            </div>

        </form>

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">

                    <tr>
                        <th width="70">No</th>
                        <th>IP Address</th>
                        <th>Total Attempt</th>
                        <th>Threshold Limit</th>
                        <th>Aksi</th>
                        <th>Waktu</th>
                    </tr>

                </thead>

                <tbody>

                <?php

                $no=1;

                while($row=mysqli_fetch_assoc($data)){

                ?>

                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['ip_address']) ?></td>
                        <td><?= htmlspecialchars($row['failed_attempts']) ?></td>
                        <td>
                            <span class="badge bg-danger">
                                <?= htmlspecialchars($row['threshold_limit']) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($row['action_taken']) ?></td>
                        <td><?= date('d-m-Y H:i:s',strtotime($row['created_at'])) ?></td>
                    </tr>

                <?php } ?>

                <?php if(mysqli_num_rows($data)===0){ ?>

                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Data threshold logs belum tersedia.
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>
