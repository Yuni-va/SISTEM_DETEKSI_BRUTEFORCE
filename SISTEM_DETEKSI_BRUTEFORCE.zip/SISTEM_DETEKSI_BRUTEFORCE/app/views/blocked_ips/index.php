<?php

require_once "config/database.php";
require_once "app/models/BlockedIP.php";

$model = new BlockedIP($conn);

if(isset($_GET['search']) && $_GET['search']!=""){
    $data=$model->search($_GET['search']);
}else{
    $data=$model->getAll();
}

$totalBlocked=$model->totalBlocked();
$totalUnblocked=$model->totalUnblocked();
$totalToday=$model->today();

?>

<div class="row mb-4">

<div class="col-md-4">

<div class="card bg-danger text-white shadow">

<div class="card-body">

<h6>Total Blocked</h6>

<h2><?= $totalBlocked ?></h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-success text-white shadow">

<div class="card-body">

<h6>Total Unblocked</h6>

<h2><?= $totalUnblocked ?></h2>

</div>

</div>

</div>

<div class="col-md-4">

<div class="card bg-primary text-white shadow">

<div class="card-body">

<h6>Hari Ini</h6>

<h2><?= $totalToday ?></h2>

</div>

</div>

</div>

</div>

<div class="card shadow">

<div class="card-header bg-primary text-white">

<div class="d-flex justify-content-between">

<h5>

<i class="bi bi-ban-fill"></i>

Blocked IP

</h5>

<a href="blocked_ips.php" class="btn btn-light btn-sm">

Refresh

</a>

</div>

</div>

<div class="card-body">

<form method="GET" class="mb-3">

<div class="input-group">

<input
type="text"
name="search"
class="form-control"
placeholder="Cari IP">

<button class="btn btn-primary">

Cari

</button>

</div>

</form>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>No</th>

<th>IP Address</th>

<th>Status</th>

<th>Blocked At</th>

<th>Blocked Until</th>

<th>Aksi</th>

</tr>

</thead>

<tbody>

<?php

$no=1;

while($row=mysqli_fetch_assoc($data)){

?>

<tr>

<td><?= $no++ ?></td>

<td><?= htmlspecialchars($row['ip_address']) ?></td>

<td>

<?php

if($row['status']=="blocked"){

echo "<span class='badge bg-danger'>BLOCKED</span>";

}else{

echo "<span class='badge bg-success'>UNBLOCKED</span>";

}

?>

</td>

<td><?= htmlspecialchars($row['blocked_at']) ?></td>

<td><?= htmlspecialchars($row['blocked_until']) ?></td>

<td>

<?php if($row['status']=="blocked"){ ?>

<form
method="POST"
action="app/controllers/BlockedIPController.php"
class="d-inline">

<?= csrf_field(); ?>

<input
type="hidden"
name="id"
value="<?= htmlspecialchars($row['id']) ?>">

<button
type="submit"
name="unblock"
class="btn btn-success btn-sm">

Unblock

</button>

</form>

<?php } ?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>
