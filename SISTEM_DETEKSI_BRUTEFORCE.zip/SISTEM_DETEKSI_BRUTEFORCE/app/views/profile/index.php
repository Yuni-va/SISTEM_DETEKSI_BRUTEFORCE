<?php

require_once "config/database.php";
require_once "app/models/User.php";

$userModel = new User($conn);
$profile = $userModel->find($_SESSION['id']);

$photo = $profile['profile_photo'] ?? "default.png";
$photoPath = "assets/uploads/profile/".$photo;
$hasPhoto = $photo !== "" && file_exists($photoPath);
$initial = strtoupper(substr($profile['fullName'] ?? $profile['username'] ?? "A",0,1));

?>

<div class="card shadow">

    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
            <i class="bi bi-person-circle"></i>
            Profil Administrator
        </h5>
    </div>

    <div class="card-body">

        <?php if(isset($_SESSION['success'])){ ?>

            <div class="alert alert-success">
                <?= htmlspecialchars($_SESSION['success']) ?>
            </div>

        <?php unset($_SESSION['success']); } ?>

        <?php if(isset($_SESSION['error'])){ ?>

            <div class="alert alert-danger">
                <?= htmlspecialchars($_SESSION['error']) ?>
            </div>

        <?php unset($_SESSION['error']); } ?>

        <form
            action="app/controllers/ProfileController.php"
            method="POST"
            enctype="multipart/form-data">

            <?= csrf_field(); ?>

            <div class="row g-4 align-items-start">

                <div class="col-lg-4">

                    <div class="text-center border rounded p-4 bg-light">

                        <?php if($hasPhoto){ ?>

                            <img
                                src="<?= htmlspecialchars($photoPath) ?>"
                                class="rounded-circle border mb-3"
                                width="150"
                                height="150"
                                style="object-fit:cover;"
                                alt="Foto profil">

                        <?php }else{ ?>

                            <div
                                class="rounded-circle border bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3"
                                style="width:150px;height:150px;font-size:56px;font-weight:700;">
                                <?= htmlspecialchars($initial) ?>
                            </div>

                        <?php } ?>

                        <h5 class="mb-1">
                            <?= htmlspecialchars($profile['fullName']) ?>
                        </h5>

                        <span class="badge bg-primary">
                            <?= htmlspecialchars($profile['role']) ?>
                        </span>

                        <div class="mt-4 text-start">
                            <label class="form-label">Foto Profil</label>
                            <input
                                type="file"
                                name="profile_photo"
                                class="form-control"
                                accept=".jpg,.jpeg,.png,.webp,.gif">
                            <small class="text-muted">
                                Format JPG, PNG, WEBP, atau GIF. Maksimal 2MB.
                            </small>
                        </div>

                    </div>

                </div>

                <div class="col-lg-8">

                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input
                                type="text"
                                name="fullname"
                                class="form-control"
                                value="<?= htmlspecialchars($profile['fullName']) ?>"
                                required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Username</label>
                            <input
                                type="text"
                                name="username"
                                class="form-control"
                                value="<?= htmlspecialchars($profile['username']) ?>"
                                required>
                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input
                                type="email"
                                name="email"
                                class="form-control"
                                value="<?= htmlspecialchars($profile['email']) ?>"
                                required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password Baru</label>
                            <input
                                type="password"
                                name="password"
                                class="form-control"
                                placeholder="Kosongkan jika tidak diubah">
                        </div>

                    </div>

                    <div class="d-flex gap-2 mt-2">
                        <button
                            type="submit"
                            name="update_profile"
                            class="btn btn-primary">
                            <i class="bi bi-save"></i>
                            Simpan Profil
                        </button>

                        <a href="dashboard.php" class="btn btn-secondary">
                            Kembali
                        </a>
                    </div>

                </div>

            </div>

        </form>

    </div>

</div>
