<?php

require_once "config/database.php";
require_once "app/models/Report.php";

$model = new Report($conn);

$from = $_GET['from'] ?? "";
$to   = $_GET['to'] ?? "";

$summary = $model->summary($from,$to);
$detections = $model->latestDetections($from,$to);

$exportQuery = http_build_query([
    "from" => $from,
    "to" => $to
]);

?>

<div class="card shadow mb-4">

    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
            <i class="bi bi-file-earmark-bar-graph"></i>
            Reports
        </h5>
    </div>

    <div class="card-body">

        <form method="GET" class="row g-3 align-items-end">

            <div class="col-md-5">
                <label class="form-label">Dari Tanggal</label>
                <input
                    type="date"
                    name="from"
                    class="form-control"
                    value="<?= htmlspecialchars($from) ?>">
            </div>

            <div class="col-md-5">
                <label class="form-label">Sampai Tanggal</label>
                <input
                    type="date"
                    name="to"
                    class="form-control"
                    value="<?= htmlspecialchars($to) ?>">
            </div>

            <div class="col-md-2">
                <button class="btn btn-primary w-100">
                    <i class="bi bi-funnel"></i>
                    Filter
                </button>
            </div>

        </form>

        <div class="d-flex flex-wrap gap-2 mt-3">
            <a
                href="app/controllers/ReportExportController.php?format=pdf&<?= $exportQuery ?>"
                class="btn btn-danger btn-sm">
                <i class="bi bi-file-earmark-pdf"></i>
                Export PDF
            </a>

            <a
                href="app/controllers/ReportExportController.php?format=excel&<?= $exportQuery ?>"
                class="btn btn-success btn-sm">
                <i class="bi bi-file-earmark-excel"></i>
                Export Excel
            </a>
        </div>

    </div>

</div>

<div class="row mb-4">

    <div class="col-lg-3 col-md-6 mb-3">
        <div class="card bg-success text-white shadow h-100">
            <div class="card-body">
                <h6>Login Berhasil</h6>
                <h2><?= $summary['success_login'] ?></h2>
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-3">
        <div class="card bg-danger text-white shadow h-100">
            <div class="card-body">
                <h6>Login Gagal</h6>
                <h2><?= $summary['failed_login'] ?></h2>
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-3">
        <div class="card bg-warning text-dark shadow h-100">
            <div class="card-body">
                <h6>Blocked IP</h6>
                <h2><?= $summary['blocked_ip'] ?></h2>
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-3">
        <div class="card bg-primary text-white shadow h-100">
            <div class="card-body">
                <h6>Detection</h6>
                <h2><?= $summary['detection'] ?></h2>
            </div>
        </div>
    </div>

</div>

<div class="row mb-4">

    <div class="col-md-12">
        <div class="card bg-secondary text-white shadow">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="mb-1">Threshold Logs</h6>
                    <h2 class="mb-0"><?= $summary['threshold'] ?></h2>
                </div>

                <i class="bi bi-sliders fs-1"></i>
            </div>
        </div>
    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-shield-exclamation"></i>
            Detection Terbaru
        </h5>

        <a href="reports.php" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-clockwise"></i>
            Reset
        </a>
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">
                    <tr>
                        <th width="70">No</th>
                        <th>Username</th>
                        <th>IP Address</th>
                        <th>Tipe</th>
                        <th>Deskripsi</th>
                        <th>Waktu</th>
                    </tr>
                </thead>

                <tbody>

                <?php

                $no=1;

                while($row=mysqli_fetch_assoc($detections)){

                ?>

                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['ip_address']) ?></td>
                        <td>
                            <span class="badge bg-danger">
                                <?= htmlspecialchars($row['detection_type']) ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($row['description']) ?></td>
                        <td><?= date('d-m-Y H:i:s',strtotime($row['detected_at'])) ?></td>
                    </tr>

                <?php } ?>

                <?php if(mysqli_num_rows($detections)===0){ ?>

                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Data laporan belum tersedia.
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>
