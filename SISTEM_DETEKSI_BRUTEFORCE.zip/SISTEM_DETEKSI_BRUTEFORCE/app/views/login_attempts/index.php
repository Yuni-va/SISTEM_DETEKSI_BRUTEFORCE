<?php

require_once "config/database.php";
require_once "app/models/LoginAttempt.php";

$model = new LoginAttempt($conn);

if(isset($_GET['search']) && $_GET['search']!=""){
    $data = $model->search($_GET['search']);
}else{
    $data = $model->getAll();
}

$totalSuccess = $model->totalSuccess();
$totalFailed  = $model->totalFailed();
$totalToday   = $model->today();

?>

<div class="row mb-4">

    <div class="col-md-4">

        <div class="card border-0 shadow bg-success text-white">

            <div class="card-body">

                <h6>Total Login Berhasil</h6>

                <h2><?= $totalSuccess ?></h2>

            </div>

        </div>

    </div>

    <div class="col-md-4">

        <div class="card border-0 shadow bg-danger text-white">

            <div class="card-body">

                <h6>Total Login Gagal</h6>

                <h2><?= $totalFailed ?></h2>

            </div>

        </div>

    </div>

    <div class="col-md-4">

        <div class="card border-0 shadow bg-primary text-white">

            <div class="card-body">

                <h6>Total Hari Ini</h6>

                <h2><?= $totalToday ?></h2>

            </div>

        </div>

    </div>

</div>

<div class="card shadow">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

        <h5 class="mb-0">

            <i class="bi bi-box-arrow-in-right"></i>

            Login Attempts

        </h5>

        <a href="login_attempts.php" class="btn btn-light btn-sm">

            <i class="bi bi-arrow-clockwise"></i>

            Refresh

        </a>

    </div>

    <div class="card-body">

        <form method="GET" class="mb-3">

            <div class="input-group">

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Cari Username / IP Address..."
                    value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>">

                <button class="btn btn-primary">

                    <i class="bi bi-search"></i>

                    Cari

                </button>

            </div>

        </form>

        <div class="table-responsive">

            <table class="table table-hover table-bordered align-middle">

                <thead class="table-dark">

                    <tr>

                        <th width="70">No</th>
                        <th>Username</th>
                        <th>IP Address</th>
                        <th>Status</th>
                        <th>Waktu Login</th>

                    </tr>

                </thead>

                <tbody>

                <?php

                $no=1;

                while($row=mysqli_fetch_assoc($data)){

                ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>

                            <?= htmlspecialchars($row['username']) ?>

                        </td>

                        <td>

                            <?= htmlspecialchars($row['ip_address']) ?>

                        </td>

                        <td>

                            <?php

                            if($row['status']=="success"){

                                echo "<span class='badge bg-success'>SUCCESS</span>";

                            }else{

                                echo "<span class='badge bg-danger'>FAILED</span>";

                            }

                            ?>

                        </td>

                        <td>

                            <?= date('d-m-Y H:i:s',strtotime($row['attempt_time'])) ?>

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>